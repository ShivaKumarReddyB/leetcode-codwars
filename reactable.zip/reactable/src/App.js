import React, { useEffect, useState } from "react";
import BasicTable from "./BasicTable"; // Assuming BasicTable is in a separate file
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import Grid from "@mui/material/Grid";

const data = {
  option1: [
    { id: 1, name: "John", age: 30 },
    { id: 2, name: "Alice", age: 25 },
  ],
  option2: [
    { id: 1, name: "Bob", age: 40 },
    { id: 2, name: "Eve", age: 35 },
  ],
};

function App() {
  const [selectedOption, setSelectedOption] = useState("option1");

  useEffect(() => {
    getData();
  }, []);

  const handleChange = (event) => {
    setSelectedOption(event.target.value);
  };

  async function getData() {
    const resp = await fetch(
      "https://api.gw.edam.edam1.fyre.ibm.com/edamorg/sandbox/fyre3/",
      {
        method: "GET",
        headers: {
          "X-IBM-Client-Id": "6e83e7a39bf77dec05d4daca7e6bc86c",
          accept: "application/json",
        },
      },
    );
    const respData = await resp.json();
    // setTableData(respData)
    console.log({ respData });
  }

  return (
    <div className="App">
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <FormControl>
            <InputLabel id="select-label">Select Option</InputLabel>
            <Select
              labelId="select-label"
              value={selectedOption}
              onChange={handleChange}
            >
              <MenuItem value="option1">Option 1</MenuItem>
              <MenuItem value="option2">Option 2</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12}>
          <BasicTable
            columns={[
              { id: "name", label: "Name" },
              { id: "age", label: "Age" },
            ]}
            rows={data[selectedOption]}
          />
        </Grid>
      </Grid>
    </div>
  );
}

export default App;
